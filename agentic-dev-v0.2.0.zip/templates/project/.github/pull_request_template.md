## What and why

<One to three sentences. The diff shows the what — write the why.>

Spec: `docs/specs/<slug>.md`
Roadmap: <the item from Now>
Workflow used: <new-feature | bug-fix | hotfix | refactor | dependency-update>

## Verification

<Commands you ran and their output. Not "tests pass" — show it.>

```
$ npm run lint && npm run typecheck && npm test && npm run build
<output>
```

- [ ] Every acceptance criterion demonstrated individually
- [ ] Tests added at the appropriate level
- [ ] Preview URL opened and checked
- [ ] Review with fresh context, no open correctness findings
- [ ] Docs updated (README / ADR / API)
- [ ] `ROADMAP.md` updated
- [ ] Learning written, if anything was surprising

## Rollback

<Required — CI checks that this section exists.>

<e.g. "Reverting this commit is enough, no migration involved."
or "Roll migration 0042 back with `npm run db:rollback`, then revert.">

## Risks

<What can break? Breaking change? Data migration? Cost? Or: "none".>
